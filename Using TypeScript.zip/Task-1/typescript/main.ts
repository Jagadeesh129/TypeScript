import { avgAndMax, checkAllUsers, isAllUsersChecked } from "../javascript/mathematicalCaluclations.js";
import {User} from "../javascript/user.js";
import {CollectionOfUsersInTable} from '../javascript/CollectionOfUsersInTable.js';

document.getElementById("caluclate").addEventListener("click",avgAndMax);
document.getElementById("select-all-checkboxes").addEventListener("change",checkAllUsers);
document.getElementById('search').addEventListener('input',searchFunction);

let users = [
    {
        name :'Jagadeeesh Mamilla',
        score :45,
        email :'jaga@gmail.com',
        id: 1
    },
    {
        name:'Ruchira Bodula',
        score:92,
        email:'ruchira@gmail.com',
        id:2
    },
    {
        name:'Sai Eguturi',
        score:88,
        email:'sai@gmail.com',
        id:3
    }
]

for(let i=0;i<users.length;i++) {
    let userDetails= users[i];
    let user=new User(userDetails);
    let objectTable=new CollectionOfUsersInTable();
    objectTable.createrow(user.name,user.score,user.email,user.id);
}

for(let i=0;i<users.length;i++) {
    let checkbox = document.getElementById((i+1).toString())
    checkbox.addEventListener("change",isAllUsersChecked);
}

function searchFunction() {
    let input = (document.getElementsByClassName("search")[0] as HTMLInputElement);
    var filter = input.value.toUpperCase();
    let table = document.getElementById("table");
    let tr = table.getElementsByTagName("tr");
    for (let i = 1; i < tr.length; i++) {
        for(let j=1;j<4;j++){
            let td = tr[i].getElementsByTagName("td")[j];
            if (td) {
                let txtValue = td.textContent;
                td.innerHTML = txtValue;
                let index = txtValue.toUpperCase().indexOf(filter);
                if (index > -1) {
                    td.innerHTML = txtValue.substring(0, index) 
                    + "<mark>" + txtValue.substring(index, index + filter.length) 
                    + "</mark>" + txtValue.substring(index + filter.length);
                }
            }
        }
    }
}