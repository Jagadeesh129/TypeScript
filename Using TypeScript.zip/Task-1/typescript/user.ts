export class User {
    name:string;
    score:number;
    email:string;
    id:number;
    constructor(userDetails:any){
        this.name=userDetails.name;
        this.score=userDetails.score;
        this.email=userDetails.email;
        this.id=userDetails.id;
    }
}