export class CollectionOfUsersInTable  {
    createrow(name:string,score:number,email:string,id:number) {
        let table=document.getElementById("table") as HTMLTableElement;
        let row=table.insertRow(table.rows.length);
        let col0=row.insertCell(0);
        let col1=row.insertCell(1);
        let col2=row.insertCell(2);
        let col3=row.insertCell(3);
        col1.innerText=name;
        col2.textContent=score.toString();
        col3.innerText=email;
        let span=document.createElement('span');
        let checkbox=document.createElement('input');
        checkbox.setAttribute('type','checkbox');
        checkbox.setAttribute('name','select');
        checkbox.setAttribute('id',id.toString());
        span.append(checkbox);
        col0.append(span);
    }

    getScore(id:number) :number{
        let table=document.getElementById("table") as HTMLTableElement;
        let objRow : any=table.rows.item(id+1).cells;
        return parseInt(objRow.item(2).innerText);
    }
}