import {CollectionOfUsersInTable} from "../javascript/CollectionOfUsersInTable.js"
var selectAllChecks:any=document.getElementById("select-all-checkboxes");
var select:any = document.getElementsByName("select");

export function avgAndMax() {
    let checks:any=document.getElementsByName("select");
    let sum=0,max=0,count=0;
    for(let i=0;i<checks.length;i++){
        if(checks[i].checked){
            count++;
            let tableObj=new CollectionOfUsersInTable();
            let score:number=tableObj.getScore(i);
            sum=sum+score;
            if(max<score){
                max=score;
            }
        }
    }
    let avg=0;
    if(count>0)
        avg=sum/count;
    document.getElementById("average-score").innerText=avg.toString();
    document.getElementById("max-score").innerText=max.toString();
}

export function checkAllUsers(){
    let checks:any=document.getElementsByName("select");
    if(selectAllChecks.checked){
        for(let i=0;i<checks.length;i++){
            checks[i].checked=true;
        }
    }
    else{
        for(let i=0;i<checks.length;i++){
            checks[i].checked=false;
        }
    }
}

export function isAllUsersChecked() {
    let k=0;
    for(let i=0;i<select.length;i++){
        if(!select[i].checked){
            selectAllChecks.checked=false;
            k=1;
            break;
        }
    }
    if(k==0){
        selectAllChecks.checked=true;
    }
}