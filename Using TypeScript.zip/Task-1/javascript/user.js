export class user {
    constructor(userDetails) {
        this.name = userDetails.name;
        this.score = userDetails.score;
        this.email = userDetails.email;
        this.id = userDetails.id;
    }
}
